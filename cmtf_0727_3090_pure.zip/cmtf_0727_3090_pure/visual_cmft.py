import warnings
warnings.filterwarnings('ignore')
warnings.simplefilter('ignore')
import torch
import torch.nn as nn
import cv2
import numpy as np
import requests
import torchvision.transforms as transforms
from pytorch_grad_cam import EigenCAM
from pytorch_grad_cam.utils.image import show_cam_on_image, scale_cam_image
from PIL import Image
from models.common import Conv

COLORS = np.random.uniform(0, 255, size=(80, 3))

def parse_detections(results):
    # detections = results.pandas().xyxy[0]
    detections = results.xyxy[0]
    detections = detections.to_dict()
    boxes, colors, names = [], [], []

    for i in range(len(detections["xmin"])):
        confidence = detections["confidence"][i]
        if confidence < 0.2:
            continue
        xmin = int(detections["xmin"][i])
        ymin = int(detections["ymin"][i])
        xmax = int(detections["xmax"][i])
        ymax = int(detections["ymax"][i])
        name = detections["name"][i]
        category = int(detections["class"][i])
        color = COLORS[category]

        boxes.append((xmin, ymin, xmax, ymax))
        colors.append(color)
        names.append(name)
    return boxes, colors, names


def draw_detections(boxes, colors, names, img):
    for box, color, name in zip(boxes, colors, names):
        xmin, ymin, xmax, ymax = box
        cv2.rectangle(
            img,
            (xmin, ymin),
            (xmax, ymax),
            color, 
            2)

        cv2.putText(img, name, (xmin, ymin - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2,
                    lineType=cv2.LINE_AA)
    return img

class Ensemble(nn.ModuleList):
    # Ensemble of models
    def __init__(self):
        super(Ensemble, self).__init__()

    def forward(self, x, augment=False):
        y = []
        for module in self:
            y.append(module(x, augment)[0])
        # y = torch.stack(y).max(0)[0]  # max ensemble
        # y = torch.stack(y).mean(0)  # mean ensemble
        y = torch.cat(y, 1)  # nms ensemble
        return y, None  # inference, train output

def attempt_load(weights, map_location=None):
    # Loads an ensemble of models weights=[a,b,c] or a single model weights=[a] or weights=a
    model = Ensemble()
    for w in weights if isinstance(weights, list) else [weights]:
        ckpt = torch.load(w, map_location=map_location)  # load
        model.append(ckpt['ema' if ckpt.get('ema') else 'model'].float().fuse().eval())  # FP32 model

    # Compatibility updates
    for m in model.modules():
        if type(m) in [nn.Hardswish, nn.LeakyReLU, nn.ReLU, nn.ReLU6, nn.SiLU]:
            m.inplace = True  # pytorch 1.7.0 compatibility
        elif type(m) is Conv:
            m._non_persistent_buffers_set = set()  # pytorch 1.6.0 compatibility

    if len(model) == 1:
        return model[-1]  # return model
    else:
        print('Ensemble created with %s\n' % weights)
        for k in ['names', 'stride']:
            setattr(model, k, getattr(model[-1], k))
        return model  # return ensemble


# device = torch.device('cuda:0')
device = torch.device('cpu')

pt_path = '/data1/housong/program/llvip-yolov5/Mod1104test/runs/train/TwoStreamMod1104testLLVIP5/weights/best.pt'

# model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)
model = attempt_load(pt_path, map_location=device)
model.eval()
model.cpu()

vis_image = '/data1/housong/program/datasets/LLVIP/yoloformat_w640/visible/images/val/190009.jpg'
inf_image = '/data1/housong/program/datasets/LLVIP/yoloformat_w640/infrared/images/val/190009.jpg'

# image_url = "https://upload.wikimedia.org/wikipedia/commons/f/f1/Puppies_%284984818141%29.jpg"
# img = np.array(Image.open(requests.get(image_url, stream=True).raw))

vis_img = np.array(Image.open(vis_image))
inf_img = np.array(Image.open(inf_image))
vis_img = cv2.resize(vis_img, (640, 640))
inf_img = cv2.resize(inf_img, (640, 640))

rgb_img_vis = vis_img.copy()
rgb_img_inf = inf_img.copy()
vis_img = np.float32(vis_img) / 255
inf_img = np.float32(inf_img) / 255
transform = transforms.ToTensor()
tensor_vis = transform(vis_img).unsqueeze(0)
tensor_inf = transform(inf_img).unsqueeze(0)

target_layers = [model.model[10]]
# imgs = imgs.to(device, non_blocking=True).float() / 255.0

img_transforms = transforms.Compose([
    transforms.Resize((640, 640)),
    transforms.ToTensor()])
img_pil_vis = Image.open(vis_image).convert('RGB')
img_tensor_vis = img_transforms(img_pil_vis) * 255.0
img_pil_inf = Image.open(inf_image).convert('RGB')
img_tensor_inf = img_transforms(img_pil_inf) * 255.0

img_tensor_vis.unsqueeze_(0)    # chw --> bchw
img_tensor_inf.unsqueeze_(0)    # chw --> bchw

print("img_tensor_inf",img_tensor_inf.shape)
with torch.no_grad(): 
    results, train_out = model(img_tensor_vis, img_tensor_inf) # out, train_out

# boxes, colors, names = parse_detections(results)
# detections = draw_detections(boxes, colors, names, rgb_img_vis.copy())
# Image.fromarray(detections)

cam = EigenCAM(model, target_layers, use_cuda=False)

# grayscale_cam = cam(tensor)[0, :, :]
grayscale_cam = cam((tensor_vis, tensor_inf))[0, :, :]

cam_image = show_cam_on_image(vis_img, grayscale_cam, use_rgb=True)
Image.fromarray(cam_image)
